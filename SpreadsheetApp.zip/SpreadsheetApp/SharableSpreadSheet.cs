﻿/*********************************************************************************
* SharableSpreadSheet
* -------------------------------------------------------------------------------
* Thread-safe spreadsheet with fine-grained locking.  Each cell is mapped to one
* of nUsers Mutex objects.  Multi-cell operations gather the distinct mutexes
* they need, sort them by hash code (deterministic order), lock them once, run,
* then release in reverse.
*
* Changes in this revision
*  • Student-style EqualsMaybeCase (no ternary or StringComparison)
*  • No lambdas/Enumerable in exchangeRows / exchangeCols
*  • addRow / addCol lock only relevant mutexes (scan until set==nUsers)
*  • Clear save/load loops (explain \t escaping)
*********************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

public class SharableSpreadSheet
{
    /* Fields -------------------------------------------------------------- */
    private int nRows;
    private int nCols;
    private readonly int nUsers;

    private string[,] data;
    private readonly List<Mutex> userMutexes;                 // size == nUsers
    private readonly Dictionary<(int, int), Mutex> cellMutex; // key→mutex

    /* Constructor --------------------------------------------------------- */
    public SharableSpreadSheet(int rows, int cols, int users)
    {
        if (rows <= 0 || cols <= 0) throw new ArgumentOutOfRangeException("size must be positive");
        if (users <= 0) throw new ArgumentOutOfRangeException("nUsers>0");

        nRows = rows;
        nCols = cols;
        nUsers = users;
        data = new string[rows, cols];
        userMutexes = new List<Mutex>(users);
        cellMutex = new Dictionary<(int, int), Mutex>(rows * cols);

        /* 1. create mutexes */
        for (int i = 0; i < nUsers; i++)
            userMutexes.Add(new Mutex(false, $"UserMutex_{i}"));

        /* 2. compute quotas for even distribution */
        int total = rows * cols;
        int baseSize = total / nUsers;
        int remainder = total % nUsers;

        int[] quota = new int[nUsers];
        for (int i = 0; i < nUsers; i++)
            quota[i] = baseSize + (i < remainder ? 1 : 0);

        /* 3. list of candidate mutex indices */
        List<int> avail = new List<int>();
        for (int i = 0; i < nUsers; i++) avail.Add(i);

        Random rnd = new Random();

        /* 4. map each cell to a mutex */
        for (int r = 0; r < nRows; r++)
            for (int c = 0; c < nCols; c++)
            {
                int k = rnd.Next(avail.Count);
                int idx = avail[k];

                cellMutex[(r, c)] = userMutexes[idx];

                if (--quota[idx] == 0)
                {
                    int last = avail.Count - 1;
                    avail[k] = avail[last];
                    avail.RemoveAt(last);
                }
            }
    }

    /* Utility helpers ----------------------------------------------------- */
    private void CheckCell(int r, int c)
    {
        if (r < 0 || r >= nRows || c < 0 || c >= nCols)
            throw new ArgumentOutOfRangeException("cell out of range");
    }

    private Mutex GetMutex(int r, int c) => cellMutex[(r, c)];

    private List<Mutex> CollectLocks(IEnumerable<(int, int)> cells)
    {
        HashSet<Mutex> set = new HashSet<Mutex>();
        foreach (var tup in cells) set.Add(GetMutex(tup.Item1, tup.Item2));

        /* Deterministic order – sort by hash code */
        List<Mutex> list = set.ToList();
        list.Sort((a, b) => a.GetHashCode().CompareTo(b.GetHashCode()));
        return list;
    }

    private static void LockAll(IEnumerable<Mutex> ms) { foreach (var m in ms) m.WaitOne(); }
    private static void UnlockAll(IEnumerable<Mutex> ms) { foreach (var m in ms.Reverse()) m.ReleaseMutex(); }

    /* Less-efficient student version ------------------------------------- */
    private static bool EqualsMaybeCase(string a, string b, bool caseSensitive)
    {
        if (caseSensitive)
        {
            return a == b;                     // direct compare
        }
        else
        {
            if (a == null || b == null) return a == b;
            return a.ToLower() == b.ToLower(); // naive case-fold
        }
    }

    /* Single-cell primitives --------------------------------------------- */
    public string getCell(int row, int col)
    {
        CheckCell(row, col);
        var m = GetMutex(row, col);
        m.WaitOne();
        try { return data[row, col]; }
        finally { m.ReleaseMutex(); }
    }

    public void setCell(int row, int col, string str)
    {
        CheckCell(row, col);
        var m = GetMutex(row, col);
        m.WaitOne();
        try { data[row, col] = str; }
        finally { m.ReleaseMutex(); }
    }

    /* Multi-cell operations ---------------------------------------------- */

    public Tuple<int, int> searchString(string str)
    {
        for (int r = 0; r < nRows; r++)
            for (int c = 0; c < nCols; c++)
            {
                var m = GetMutex(r, c);
                m.WaitOne();
                try
                {
                    if (data[r, c] == str) return Tuple.Create(r, c);
                }
                finally { m.ReleaseMutex(); }
            }
        return Tuple.Create(-1, -1);
    }

    public void exchangeRows(int row1, int row2)
    {
        if (row1 == row2) return;
        if (row1 < 0 || row1 >= nRows || row2 < 0 || row2 >= nRows)
            throw new ArgumentOutOfRangeException("row index bad");

        /* Build list of affected cells without lambdas */
        var cells = new List<(int, int)>();
        for (int c = 0; c < nCols; c++)
        {
            cells.Add((row1, c));
            cells.Add((row2, c));
        }

        var locks = CollectLocks(cells);
        LockAll(locks);
        try
        {
            for (int c = 0; c < nCols; c++)
                (data[row1, c], data[row2, c]) = (data[row2, c], data[row1, c]);
        }
        finally { UnlockAll(locks); }
    }

    public void exchangeCols(int col1, int col2)
    {
        if (col1 == col2) return;
        if (col1 < 0 || col1 >= nCols || col2 < 0 || col2 >= nCols)
            throw new ArgumentOutOfRangeException("column index bad");

        var cells = new List<(int, int)>();
        for (int r = 0; r < nRows; r++)
        {
            cells.Add((r, col1));
            cells.Add((r, col2));
        }

        var locks = CollectLocks(cells);
        LockAll(locks);
        try
        {
            for (int r = 0; r < nRows; r++)
                (data[r, col1], data[r, col2]) = (data[r, col2], data[r, col1]);
        }
        finally { UnlockAll(locks); }
    }

    public int searchInRow(int row, string str)
    {
        if (row < 0 || row >= nRows) throw new ArgumentOutOfRangeException();

        for (int c = 0; c < nCols; c++)
        {
            var m = GetMutex(row, c);
            m.WaitOne();
            try
            {
                if (data[row, c] == str) return c;
            }
            finally { m.ReleaseMutex(); }
        }
        return -1;
    }

    public int searchInCol(int col, string str)
    {
        if (col < 0 || col >= nCols) throw new ArgumentOutOfRangeException();

        for (int r = 0; r < nRows; r++)
        {
            var m = GetMutex(r, col);
            m.WaitOne();
            try
            {
                if (data[r, col] == str) return r;
            }
            finally { m.ReleaseMutex(); }
        }
        return -1;
    }

    public Tuple<int, int> searchInRange(int col1, int col2, int row1, int row2, string str)
    {
        if (row1 < 0 || row2 >= nRows || col1 < 0 || col2 >= nCols || row1 > row2 || col1 > col2)
            throw new ArgumentOutOfRangeException("range bad");

        for (int r = row1; r <= row2; r++)
            for (int c = col1; c <= col2; c++)
            {
                var m = GetMutex(r, c);
                m.WaitOne();
                try
                {
                    if (data[r, c] == str) return Tuple.Create(r, c);
                }
                finally { m.ReleaseMutex(); }
            }
        return Tuple.Create(-1, -1);
    }

    /* --------------------  addRow / addCol  ----------------------------- */

    public void addRow(int row1)
    {
        if (row1 < 0 || row1 >= nRows)
            throw new ArgumentOutOfRangeException(nameof(row1));

        /* Gather mutexes from rows row1 .. end until we have them all */
        HashSet<Mutex> set = new HashSet<Mutex>();
        for (int r = row1; r < nRows && set.Count < nUsers; r++)
            for (int c = 0; c < nCols; c++)
                set.Add(GetMutex(r, c));

        var locks = set.Count == nUsers ? userMutexes : set.ToList();
        locks.Sort((a, b) => a.GetHashCode().CompareTo(b.GetHashCode()));
        LockAll(locks);
        try
        {
            /* allocate new array */
            string[,] newData = new string[nRows + 1, nCols];

            /* copy rows up to row1 unchanged */
            for (int r = 0; r <= row1; r++)
                for (int c = 0; c < nCols; c++)
                    newData[r, c] = data[r, c];

            /* copy rows row1+1.. end shifted down */
            for (int r = row1 + 1; r < nRows; r++)
                for (int c = 0; c < nCols; c++)
                    newData[r + 1, c] = data[r, c];

            /* update mapping dictionary */
            var newMap = new Dictionary<(int, int), Mutex>((nRows + 1) * nCols);

            // rows 0..row1
            for (int r = 0; r <= row1; r++)
                for (int c = 0; c < nCols; c++)
                    newMap[(r, c)] = cellMutex[(r, c)];

            // new empty row (row1+1)
            Random rnd = new Random();
            for (int c = 0; c < nCols; c++)
                newMap[(row1 + 1, c)] = userMutexes[rnd.Next(nUsers)];

            // shifted rows
            for (int r = row1 + 1; r < nRows; r++)
                for (int c = 0; c < nCols; c++)
                    newMap[(r + 1, c)] = cellMutex[(r, c)];

            data = newData;
            cellMutex.Clear();
            foreach (var kv in newMap) cellMutex[kv.Key] = kv.Value;
            nRows += 1;
        }
        finally { UnlockAll(locks); }
    }

    public void addCol(int col1)
    {
        if (col1 < 0 || col1 >= nCols)
            throw new ArgumentOutOfRangeException(nameof(col1));

        /* Gather mutexes from columns col1 .. end */
        HashSet<Mutex> set = new HashSet<Mutex>();
        for (int c = col1; c < nCols && set.Count < nUsers; c++)
            for (int r = 0; r < nRows; r++)
                set.Add(GetMutex(r, c));

        var locks = set.Count == nUsers ? userMutexes : set.ToList();
        locks.Sort((a, b) => a.GetHashCode().CompareTo(b.GetHashCode()));
        LockAll(locks);
        try
        {
            string[,] newData = new string[nRows, nCols + 1];

            /* copy columns left of col1 */
            for (int r = 0; r < nRows; r++)
                for (int c = 0; c <= col1; c++)
                    newData[r, c] = data[r, c];

            /* copy columns col1+1 .. end shifted right */
            for (int r = 0; r < nRows; r++)
                for (int c = col1 + 1; c < nCols; c++)
                    newData[r, c + 1] = data[r, c];

            /* mapping */
            var newMap = new Dictionary<(int, int), Mutex>(nRows * (nCols + 1));

            // existing columns left
            for (int r = 0; r < nRows; r++)
                for (int c = 0; c <= col1; c++)
                    newMap[(r, c)] = cellMutex[(r, c)];

            // new empty column
            Random rnd = new Random();
            for (int r = 0; r < nRows; r++)
                newMap[(r, col1 + 1)] = userMutexes[rnd.Next(nUsers)];

            // shifted columns
            for (int r = 0; r < nRows; r++)
                for (int c = col1 + 1; c < nCols; c++)
                    newMap[(r, c + 1)] = cellMutex[(r, c)];

            data = newData;
            cellMutex.Clear();
            foreach (var kv in newMap) cellMutex[kv.Key] = kv.Value;
            nCols += 1;
        }
        finally { UnlockAll(locks); }
    }

    /* -------------------------------------------------------------------- */

    public Tuple<int, int>[] findAll(string str, bool caseSensitive)
    {
        List<Tuple<int, int>> res = new();
        for (int r = 0; r < nRows; r++)
            for (int c = 0; c < nCols; c++)
            {
                var m = GetMutex(r, c);
                m.WaitOne();
                try
                {
                    if (EqualsMaybeCase(data[r, c], str, caseSensitive))
                        res.Add(Tuple.Create(r, c));
                }
                finally { m.ReleaseMutex(); }
            }
        return res.ToArray();
    }

    public void setAll(string oldStr, string newStr, bool caseSensitive)
    {
        List<(int, int)> toChange = new();

        /* first pass – discover targets */
        for (int r = 0; r < nRows; r++)
            for (int c = 0; c < nCols; c++)
            {
                var m = GetMutex(r, c);
                m.WaitOne();
                try
                {
                    if (EqualsMaybeCase(data[r, c], oldStr, caseSensitive))
                        toChange.Add((r, c));
                }
                finally { m.ReleaseMutex(); }
            }

        var locks = CollectLocks(toChange);
        LockAll(locks);
        try
        {
            foreach (var (r, c) in toChange)
                data[r, c] = newStr;
        }
        finally { UnlockAll(locks); }
    }

    public Tuple<int, int> getSize() => Tuple.Create(nRows, nCols);

    /* -------------------- Persistence (clear version) ------------------- */
    public void save(string fileName)
    {
        /* lock entire sheet */
        LockAll(userMutexes);
        try
        {
            using StreamWriter sw = new StreamWriter(fileName);

            /* first line – dimensions */
            sw.WriteLine($"{nRows}\t{nCols}");

            /* each subsequent line – one row, tab-separated */
            for (int r = 0; r < nRows; r++)
            {
                string[] rowArr = new string[nCols];

                for (int c = 0; c < nCols; c++)
                {
                    /* replace real tab with backslash+t so we can split safely */
                    string cell = data[r, c] ?? "";
                    cell = cell.Replace("\t", "\\t");
                    rowArr[c] = cell;
                }

                /* join using tab char */
                string line = string.Join('\t', rowArr);
                sw.WriteLine(line);
            }
        }
        finally { UnlockAll(userMutexes); }
    }

    public void load(string fileName)
    {
        LockAll(userMutexes);
        try
        {
            string[] lines = File.ReadAllLines(fileName);
            if (lines.Length == 0) throw new Exception("empty file");

            string[] dims = lines[0].Split('\t');
            int newRows = int.Parse(dims[0]);
            int newCols = int.Parse(dims[1]);

            string[,] newData = new string[newRows, newCols];

            for (int r = 0; r < newRows; r++)
            {
                string[] parts = lines[r + 1].Split('\t');

                for (int c = 0; c < newCols; c++)
                {
                    string cell = c < parts.Length ? parts[c] : "";
                    /* undo the escape sequence */
                    cell = cell.Replace("\\t", "\t");
                    newData[r, c] = cell;
                }
            }

            /* overwrite */
            nRows = newRows;
            nCols = newCols;
            data = newData;

            /* rebuild mapping – simple round-robin */
            cellMutex.Clear();
            int idx = 0;
            for (int r = 0; r < nRows; r++)
                for (int c = 0; c < nCols; c++)
                {
                    cellMutex[(r, c)] = userMutexes[idx];
                    idx = (idx + 1) % nUsers;
                }
        }
        finally { UnlockAll(userMutexes); }
    }
}
