﻿using System;
using System.IO;
using System.Windows.Forms;
using SpreadSheet;     // reference to your class-library

namespace SpreadsheetApp
{
    public class FormMain : Form
    {
        private SpreadSheet.SharableSpreadSheet sheet;
        private DataGridView grid;
        private MenuStrip menu;

        /* ---------------------- ctor / init -------------------------- */
        public FormMain()
        {
            Text = "Sharable Spreadsheet Demo";
            Width = 900;
            Height = 600;

            /* create MenuStrip */
            menu = new MenuStrip();
            var file = new ToolStripMenuItem("&File");
            var mNew = new ToolStripMenuItem("&New", null, OnNew) { ShortcutKeys = Keys.Control | Keys.N };
            var mLoad = new ToolStripMenuItem("&Load", null, OnLoad) { ShortcutKeys = Keys.Control | Keys.L };
            var mSave = new ToolStripMenuItem("&Save", null, OnSave) { ShortcutKeys = Keys.Control | Keys.S };
            file.DropDownItems.AddRange(new[] { mNew, mLoad, mSave });
            menu.Items.Add(file);
            MainMenuStrip = menu;
            Controls.Add(menu);

            /* create DataGridView */
            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                AllowUserToResizeColumns = true,
                SelectionMode = DataGridViewSelectionMode.CellSelect,
                EditMode = DataGridViewEditMode.EditOnEnter,
                BorderStyle = BorderStyle.Fixed3D,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
            };
            grid.CellValueChanged += Grid_CellValueChanged;
            Controls.Add(grid);

            /* default sheet 10×10 */
            CreateNewSheet(10, 10);
        }

        /* ---------------------- helpers ------------------------------ */

        private void CreateNewSheet(int rows, int cols)
        {
            sheet = new SharableSpreadSheet(rows, cols, 8); // 8 mutexes default
            RebuildGrid();
        }

        private void RebuildGrid()
        {
            var size = sheet.getSize();
            int rows = size.Item1;
            int cols = size.Item2;

            grid.Columns.Clear();
            grid.Rows.Clear();

            /* build columns */
            for (int c = 0; c < cols; c++)
            {
                var col = new DataGridViewTextBoxColumn
                {
                    HeaderText = c.ToString(),
                    Width = 80
                };
                grid.Columns.Add(col);
            }

            /* build rows */
            grid.Rows.Add(rows);
            for (int r = 0; r < rows; r++)
                grid.Rows[r].HeaderCell.Value = r.ToString();

            /* fill data */
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                    grid[c, r].Value = sheet.getCell(r, c);
        }

        /* ---------------------- event handlers ------------------------ */

        private void Grid_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            string text = grid[e.ColumnIndex, e.RowIndex].Value?.ToString() ?? "";
            sheet.setCell(e.RowIndex, e.ColumnIndex, text);
        }

        private void OnNew(object sender, EventArgs e)
        {
            using var dlg = new NewSheetDlg();
            if (dlg.ShowDialog() == DialogResult.OK)
                CreateNewSheet(dlg.Rows, dlg.Cols);
        }

        private void OnLoad(object sender, EventArgs e)
        {
            using var ofd = new OpenFileDialog { Filter = "Spreadsheet (*.txt)|*.txt|All files|*.*" };
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                sheet.load(ofd.FileName);
                RebuildGrid();
            }
        }

        private void OnSave(object sender, EventArgs e)
        {
            using var sfd = new SaveFileDialog { Filter = "Spreadsheet (*.txt)|*.txt|All files|*.*" };
            if (sfd.ShowDialog() == DialogResult.OK)
                sheet.save(sfd.FileName);
        }
    }

    /* ---------------- Dialog for New Sheet --------------------------- */
    internal sealed class NewSheetDlg : Form
    {
        private NumericUpDown numRows = new NumericUpDown { Minimum = 1, Maximum = 5000, Value = 10 };
        private NumericUpDown numCols = new NumericUpDown { Minimum = 1, Maximum = 5000, Value = 10 };

        public int Rows => (int)numRows.Value;
        public int Cols => (int)numCols.Value;

        public NewSheetDlg()
        {
            Text = "New Spreadsheet";
            Width = 250;
            Height = 160;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;

            var lblRows = new Label { Text = "Rows:", Left = 10, Top = 20, Width = 60 };
            numRows.Left = 80; numRows.Top = 18; numRows.Width = 100;

            var lblCols = new Label { Text = "Cols:", Left = 10, Top = 60, Width = 60 };
            numCols.Left = 80; numCols.Top = 58; numCols.Width = 100;

            var ok = new Button { Text = "OK", Left = 30, Width = 70, Top = 95, DialogResult = DialogResult.OK };
            var cancel = new Button { Text = "Cancel", Left = 120, Width = 70, Top = 95, DialogResult = DialogResult.Cancel };
            AcceptButton = ok; CancelButton = cancel;

            Controls.AddRange(new Control[] { lblRows, numRows, lblCols, numCols, ok, cancel });
        }
    }
}
